/**
 * @file common.h
 * @author ömer ÇAYLAN (omerceylan38@gmail.com)
 * @brief 
 * @version 0.1
 * @date 2022-07-06
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#ifndef __COMMON_H
#define __COMMON_H

typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned char bool;
#define true  1
#define false 0

#define TEST

#endif /* __COMMON_h */


